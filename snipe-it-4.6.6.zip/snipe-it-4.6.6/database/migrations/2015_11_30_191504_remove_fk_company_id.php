<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class RemoveFkCompanyId extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		//
    // Schema::table('users', function(Blueprint $table)
    // {
    //   $table->dropForeign('users_company_id_foreign');
    // });
    //
    // Schema::table('accessories', function(Blueprint $table)
    // {
    //   $table->dropForeign('accessories_company_id_foreign');
    // });
    //
    // Schema::table('assets', function(Blueprint $table)
    // {
    //   $table->dropForeign('assets_company_id_foreign');
    // });
    //
    // Schema::table('consumables', function(Blueprint $table)
    // {
    //   $table->dropForeign('consumables_company_id_foreign');
    // });
    //
    // Schema::table('licenses', function(Blueprint $table)
    // {
    //   $table->dropForeign('licenses_company_id_foreign');
    // });


	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		//
	}

}
